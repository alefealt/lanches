
var krms_config ={	
	'ApiUrl' : "Https://lanchestodahora.com.br/mobileapp/api",
	'DialogDefaultTitle' : "Lanchestodahora",
	'pushNotificationSenderid' : "674153995913",
	'facebookAppId' : "211701072675240",
	'APIHasKey' : "2ead6cd3669ec5949a97ec3d001684a7"
};